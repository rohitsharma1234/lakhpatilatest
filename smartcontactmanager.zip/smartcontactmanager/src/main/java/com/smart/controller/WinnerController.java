package com.smart.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.smart.dao.WinnerRepository;
import com.smart.entities.Winner;

@Controller
@RequestMapping("/winners")
public class WinnerController {
    @Autowired
    private WinnerRepository winnerRepository;

    @RequestMapping(value="/{contestId}", method = {RequestMethod.GET, RequestMethod.POST})
    public String listWinners(@PathVariable Long contestId, Model model) {
        List<Winner> winners = winnerRepository.findByContestIdOrderByPositionAsc(contestId);
        model.addAttribute("winners", winners);
        return "winnerList";
    }
}
