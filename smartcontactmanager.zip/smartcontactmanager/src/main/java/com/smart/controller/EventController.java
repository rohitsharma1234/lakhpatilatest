package com.smart.controller;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.smart.config.CustomUserDetails;
import com.smart.dao.EventRepository;
import com.smart.dao.UserRepository;
import com.smart.entities.Event;
import com.smart.entities.User;
import com.smart.service.EventService;



@RestController
@RequestMapping("/events")
public class EventController {
    @Autowired
    private EventService eventService;
    
    @Autowired
    private EventRepository eventRepository;
    
    @Autowired
    private UserRepository userRepository;
    
 
    @GetMapping("/getEvents")
    public ModelAndView getAllEvents(Model m) {
       Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
        User user = userDetails.getUser();
        System.out.println(user.getId());

        // Retrieve the list of events from the database
       List<Event> eventList = eventService.getAllEvents();

        // Create a new ModelAndView object with the events list and the name of the template
       ModelAndView modelAndView = new ModelAndView();
       modelAndView.addObject("eventList", eventList);
      modelAndView.addObject("userId", user.getId());
       modelAndView.setViewName("eventList");
      
       // Return the ModelAndView object
      return modelAndView;
   }



//    @GetMapping
//    public String getAllEvents(Model m) {
//      this.eventService.getAllEvents();
//      //m.addAttribute("events", events);
//      
//      return "normal/upcoming_event";
//    }

   

    @PostMapping
    public Event createEvent(@RequestBody Event event) {
        return eventService.createEvent(event);
    }

    @PutMapping("/{id}")
    public Event updateEvent(@RequestBody Event event, @PathVariable Long id) {
        event.setId(id);
        return eventService.updateEvent(event);
    }

    @DeleteMapping("/{id}")
    public void deleteEvent(@PathVariable Long id) {
        eventService.deleteEvent(id);
    }

   
    
   
    
    


    
    @PostMapping("/joinEvent")
    public ResponseEntity<String> joinEvent(@RequestParam Long eventId, @RequestParam Long userId) {
        if (eventId == null || userId == null) {
            return ResponseEntity.badRequest().body("Event or user ID cannot be null");
        }

        Event event = eventRepository.findById(eventId).orElse(null);
        User user = userRepository.findById(userId).orElse(null);

        if (event == null) {
            return ResponseEntity.badRequest().body("Event with id " + eventId + " not found");
        }

        if (user == null) {
            return ResponseEntity.badRequest().body("User with id " + userId + " not found");
        }

        // check if user has already joined the event
        if (event.getUsers().contains(user)) {
            return ResponseEntity.badRequest().body("User has already joined the event");
        }

        // check if there are tickets available
        if (event.getTicketAvailable() <= 0) {
            return ResponseEntity.badRequest().body("No tickets available for the event");
        }

        // add the user to the event and reduce ticket count
        event.getUsers().add(user);
        event.setTicketAvailable(event.getTicketAvailable() - 1);
        eventRepository.save(event);

        return ResponseEntity.ok("User with id " + userId + " joined event with id " + eventId);
    }

   

   
}

