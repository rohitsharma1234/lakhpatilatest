package com.smart.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import com.smart.config.CustomUserDetails;
import com.smart.dao.CompletedRepo;
import com.smart.dao.EventRepository;
import com.smart.entities.CompletedEvent;
import com.smart.entities.User;

@Controller
public class CompletedEventController {

	
	
	  @Autowired
	  private CompletedRepo eventRepository;
	
	@GetMapping("/getLastThreeEvents")
	public ModelAndView getLastThreeEvents(Model m) {
	   Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
	    CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
	    User user = userDetails.getUser();
	    System.out.println(user.getId());

	    // Retrieve the last three events from the database
	   List<CompletedEvent> eventList = eventRepository.findFirst3ByOrderByIdDesc();

	    // Create a new ModelAndView object with the events list and the name of the template
	   ModelAndView modelAndView = new ModelAndView();
	   modelAndView.addObject("eventList", eventList);
	   modelAndView.addObject("userId", user.getId());
	   modelAndView.setViewName("lastThreeEvents");
	  
	   // Return the ModelAndView object
	  return modelAndView;
	}

}
