package com.smart.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.smart.entities.CompletedEvent;
import com.smart.entities.Winner;


@Repository
public interface WinnerRepository extends JpaRepository<Winner, Long> {
	List<Winner> findByContestIdOrderByPositionAsc(Long contestId);
}