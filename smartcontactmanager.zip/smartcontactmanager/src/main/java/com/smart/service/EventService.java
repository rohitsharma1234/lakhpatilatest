package com.smart.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.smart.dao.EventRepository;
import com.smart.entities.Event;



@Service
public class EventService {
    @Autowired
    private EventRepository eventRepository;

    public List<Event> getAllEvents() {
        return (List<Event>) eventRepository.findAll();
    }

    public Event getEventById(Long id) {
        return eventRepository.findById(id).orElse(null);
    }

    public Event createEvent(Event event) {
        return eventRepository.save(event);
    }

    public Event updateEvent(Event event) {
        return eventRepository.save(event);
    }

    public void deleteEvent(Long id) {
        eventRepository.deleteById(id);
    }
    
    public boolean purchaseTicket(Long eventId) {
        Event event = eventRepository.findById(eventId).orElse(null);
        if (event == null || event.getTicketAvailable() <= 0) {
            return false;
        }
        event.setTicketAvailable(event.getTicketAvailable() - 1);
        eventRepository.save(event);
        return true;
    }
}

